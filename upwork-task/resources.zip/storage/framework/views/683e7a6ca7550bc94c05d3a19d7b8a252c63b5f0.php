

<?php $__env->startSection('content'); ?>
<main id="main" class="main">

    <div class="pagetitle d-flex justify-content-between">
      <h1>Users</h1>
      <button type="button" class="btn btn-sm btn-success btn-lg me-4 ps-3 pe-3" data-bs-toggle="modal" data-bs-target="#add_modal"> Add </button>
    </div>

    <section class="section dashboard">
      <div class="row">

        <!-- Left side columns -->
        <div class="col-lg-12">
          <div class="row">


            <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong><?php echo e($message); ?></strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
    <?php endif; ?>

    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <strong><?php echo e($error); ?></strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            <!-- Top Selling -->
            <div class="col-12 ">
              <div class="card top-selling">

                <div class="card-body pb-0">

                  <table class="table table-borderless table-responsive">
                    <thead>
                      <tr>
                        <th scope="col">Name</th>
                        <th scope="col">Reg No</th>
                        <th scope="col">Gender</th>
                        <th scope="col">Marital Status</th>
                        <th scope="col">Date of birth</th>
                        <th scope="col">State</th>
                        <th scope="col">Date of birth</th>
                        <th scope="col">image</th>
                        <th scope="col">Action</th>

                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <th scope="row"> <?php echo e($user->name); ?></th>
                        <th scope="row"> <?php echo e($user->reg_no); ?></th>
                        <th scope="row"> <?php echo e($user->gender); ?></th>
                        <th scope="row"> <?php echo e($user->marital_status); ?></th>
                        <th scope="row"> <?php echo e($user->mangalik_status); ?></th>
                        <th scope="row"> <?php echo e($user->birth_date); ?></th>
                        <th scope="row"> <?php echo e($user->state); ?></th>
                        <th scope="row"> <img src="<?php echo e(url('/images/'.$user->image_file)); ?>" alt="" style="height: 35px; width:40px"> </th>
                   
                        <td>
                          <button type="button" class="btn btn-sm btn-outline-success editButton" data-id="<?php echo e($user->id); ?>"> edit </button>
                          <button type="button" class="btn btn-sm btn-outline-danger deleteButton" data-id="<?php echo e($user->id); ?>">delete </button>

                        </td>
                      </tr>

                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>

                </div>

                <nav aria-label="Page navigation example" style="float: right">
                  <ul class="pagination">
                      <?php if($users->onFirstPage()): ?>
                      <li class="page-item disabled"> <a class="page-link" >Previous</a></li>
                      <?php else: ?>
                      <li class="page-item"> <a class="page-link" href="<?php echo e($users->previousPageUrl()); ?>" >Previous</a></li>
                      <?php endif; ?>

                      <?php if($users->hasMorePages()): ?>
                          <li class="page-item"> <a class="page-link" href="<?php echo e($users->nextPageUrl()); ?>">Next</a></li>
                      <?php else: ?>
                          <li class="page-item disabled"> <a class="page-link">Next</a></li>
                      <?php endif; ?>

                  </ul>
              </nav>

              </div>
            </div><!-- End Top Selling -->

          </div>
        </div><!-- End Left side columns -->

      </div>
    </section>

    
    <!-- Modal -->
    <div class="modal fade" id="add_modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog ">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Add User Data</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <form action="<?php echo e(route('import_csv')); ?>" method="POST" enctype="multipart/form-data">

              <?php echo csrf_field(); ?>
              <div class="mb-3">
                <label class="form-label" for="csv" class="form-label">CSV File</label>
                <input class="form-control" id="csv" name="csv" type="file" accept=".csv, text/csv" />
              </div>

   
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Upload</button>
          </div>

        </form>
        </div>
      </div>
    </div>

    
    <form action="<?php echo e(route('delete_user')); ?>" method="POST" id="user_delete_hdiden_form" hidden>
      <?php echo csrf_field(); ?>
      <input type="number" name="user_id" id="form_user_id">
    </form>

        
    <!-- Modal -->
    <div class="modal fade" id="add_modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog ">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Edit User</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <form action="" method="POST" enctype="multipart/form-data">

              <?php echo csrf_field(); ?>
              <div class="mb-3">
                <label class="form-label" for="csv" class="form-label">CSV File</label>
                <input class="form-control" id="csv" name="csv" type="file" accept=".csv, text/csv" />
              </div>

   
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Upload</button>
          </div>

        </form>
        </div>
      </div>
    </div>

  </main>



<?php $__env->stopSection(); ?>




<?php $__env->startSection('script'); ?>

  <script>
     $(document).ready(function(){
     
        $('.deleteButton').on('click', function(){
              if (confirm("Are You Sure!")) {
                    const selectedId = $(this).attr('data-id');
                    console.log(selectedId);
                    elementFinder('form_user_id').value = selectedId;
                    elementFinder('user_delete_hdiden_form').submit();

              } else {
                $(this).preventDefault();
              }

        });


        function elementFinder(id){
            return document.getElementById(id);
        }
     });
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\upwork\upwork-task\resources\views/admin/users.blade.php ENDPATH**/ ?>