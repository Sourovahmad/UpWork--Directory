  

  <?php $__env->startSection('content'); ?>
  
  <main id="main" class="main">

    <div class="pagetitle d-flex justify-content-between">
      <h1>Todo</h1>
      <button type="button" class="btn btn-sm btn-success btn-lg me-4 ps-3 pe-3" data-bs-toggle="modal" data-bs-target="#create_todo"> Add </button>
    </div>

    <section class="section dashboard">
      <div class="row">

       
        <div class="col-lg-12">
          <div class="row">


            <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong><?php echo e($message); ?></strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
    <?php endif; ?>

    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <strong><?php echo e($error); ?></strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


           
            <div class="col-12">
              <div class="card top-selling">

                <div class="card-body pb-0">

                  <table class="table table-borderless">
                    <thead>
                      <tr>
                        <th scope="col">Image</th>
                        <th scope="col">Phase Title</th>
                        <th scope="col">Item first</th>
                        <th scope="col">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <th scope="row"> <img src="<?php echo e($todo->image); ?>" alt=""> </th>
                        <td><a href="#" class="text-primary fw-bold"><?php echo e($todo->title); ?></a></td>
                        <td><a href="#" class="text-primary fw-bold"><?php echo e($todo->desc); ?></a></td>
                            
                        <td>
                          <button type="button" class="btn btn-sm btn-outline-success todoeditButton" data-id="<?php echo e($todo->id); ?>"> edit </button>
                          <button type="button" class="btn btn-sm btn-outline-danger tododeleteButton" data-id="<?php echo e($todo->id); ?>">delete </button>

                        </td>
                      </tr>

                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>

                </div>


                 <nav aria-label="Page navigation example" style="float: right">
                  <ul class="pagination">
                      <?php if($todos->onFirstPage()): ?>
                      <li class="page-item disabled"> <a class="page-link" >Previous</a></li>
                      <?php else: ?>
                      <li class="page-item"> <a class="page-link" href="<?php echo e($todos->previousPageUrl()); ?>" >Previous</a></li>
                      <?php endif; ?>

                      <?php if($todos->hasMorePages()): ?>
                          <li class="page-item"> <a class="page-link" href="<?php echo e($todos->nextPageUrl()); ?>">Next</a></li>
                      <?php else: ?>
                          <li class="page-item disabled"> <a class="page-link">Next</a></li>
                      <?php endif; ?>

                  </ul>
              </nav> 


              </div>
            </div>
          </div>
        </div>

      </div>
    </section>

  </main>
  
  
  <!-- End #main -->
 <?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

  <script>
     $(document).ready(function(){
        $('.todoeditButton').on('click', function(){
            const alltodos = <?php echo json_encode($todos, 15, 512) ?>;

            const todos = alltodos.data;
            const selectedId = $(this).attr('data-id');
            const todo = todos.find(r => r.id == selectedId);

            elementFinder('hidden_todo_id').value = todo.id
            elementFinder('todo_title').value = todo.title;
            elementFinder('todo_desc').value = todo.desc;

            const editModal = new bootstrap.Modal(document.getElementById('edit_todo'), {});
            editModal.show();
        });



        $('.tododeleteButton').on('click', function(){
              if (confirm("Are You Sure!")) {
                    const selectedId = $(this).attr('data-id');
                    elementFinder('delete_todo_id').value = selectedId;
                    elementFinder('delete_todo_button').click();

              } else {
                $(this).preventDefault();
              }

        });


        function elementFinder(id){
            return document.getElementById(id);
        }
     });
  </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Laravel\140\resources\views/admin/todo.blade.php ENDPATH**/ ?>