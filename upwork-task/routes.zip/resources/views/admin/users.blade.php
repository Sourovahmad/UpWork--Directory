@extends('admin.master')

@section('content')
<main id="main" class="main">

    <div class="pagetitle d-flex justify-content-between">
      <h1>Users</h1>
      <div>
        <button type="button" class="btn btn-sm btn-success btn-lg me-4 ps-3 pe-3" data-bs-toggle="modal" data-bs-target="#add_modal"> Add </button>
      <button type="button" class="btn btn-sm btn-info btn-lg me-4 ps-3 pe-3" data-bs-toggle="modal" data-bs-target="#setting_modal"><span class="iconify" data-icon="icon-park:setting" style="font-size:22px"></span>  </button>

      </div>
      
    </div>

    <section class="section dashboard">
      <div class="row">

        <!-- Left side columns -->
      <div class="col-lg-12">
          <div class="row">


            @if ($message = Session::get('success'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>{{ $message }}</strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
    @endif

    @foreach ($errors->all() as $error)
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <strong>{{ $error }}</strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
    @endforeach


            <!-- Top Selling -->
            <div class="col-12 ">
              <div class="card top-selling">

                <div class="card-body pb-0">

                  <table class="table table-borderless table-responsive">
                    <thead>
                      <tr>
                        <th scope="col">Name</th>
                        <th scope="col">Reg No</th>
                        <th scope="col">Password</th>
                        <th scope="col">Gender</th>
                        <th scope="col">Marital Status</th>
                        <th scope="col">Mangalik Staus</th>
                        <th scope="col">State</th>
                        <th scope="col">birth Year</th>
                        <th scope="col">image</th>
                        <th scope="col">Action</th>

                      </tr>
                    </thead>
                    <tbody>
                      @foreach ($users as $user)
                      <tr>
                        <th scope="row"> {{ $user->name }}</th>
                        <th scope="row"> {{ $user->reg_no }}</th>
                        <th scope="row"> {{ $user->password }}</th>
                        <th scope="row"> {{ $user->gender }}</th>
                        <th scope="row"> {{ $user->marital_status }}</th>
                        <th scope="row"> {{ $user->mangalik_status }}</th>
                        <th scope="row"> {{ $user->state }}</th>
                        <th scope="row"> {{ $user->year }}</th>
                        <th scope="row"> <img src="{{ url('/images/'.$user->image_file) }}" alt="" style="height: 35px; width:40px"> </th>
                   
                        <td>
                          <button type="button" class="btn btn-sm btn-outline-success editButton" data-id="{{ $user->id }}"> edit </button>
                          <button type="button" class="btn btn-sm btn-outline-danger deleteButton" data-id="{{ $user->id }}">delete </button>

                        </td>
                      </tr>

                     @endforeach
                    </tbody>
                  </table>

                </div>

                <nav aria-label="Page navigation example" style="float: right">
                  <ul class="pagination">
                      @if($users->onFirstPage())
                      <li class="page-item disabled"> <a class="page-link" >Previous</a></li>
                      @else
                      <li class="page-item"> <a class="page-link" href="{{ $users->previousPageUrl() }}" >Previous</a></li>
                      @endif

                      @if ($users->hasMorePages())
                          <li class="page-item"> <a class="page-link" href="{{ $users->nextPageUrl() }}">Next</a></li>
                      @else
                          <li class="page-item disabled"> <a class="page-link">Next</a></li>
                      @endif

                  </ul>
              </nav>

              </div>
            </div><!-- End Top Selling -->

          </div>
        </div><!-- End Left side columns -->

      </div>
    </section>

    
    <!-- Modal -->
    <div class="modal fade" id="add_modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog ">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Add User Data</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <form action="{{ route('import_csv') }}" method="POST" enctype="multipart/form-data">

              @csrf
              <div class="mb-3">
                <label class="form-label" for="csv" class="form-label">CSV File</label>
                <input class="form-control" id="csv" name="csv" type="file" accept=".csv, text/csv" />
              </div>

   
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Upload</button>
          </div>

        </form>
        </div>
      </div>
    </div>

    {{-- form for delete user --}}
    <form action="{{ route('delete_user') }}" method="POST" id="user_delete_hdiden_form" hidden>
      @csrf
      <input type="number" name="user_id" id="form_user_id">
    </form>

        
    <!-- Modal -->
    <div class="modal fade" id="setting_modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog ">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Edit User</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <form action="{{ route('change_status') }}" method="POST" enctype="multipart/form-data">

              @csrf
              <div class="mb-3">
                <div class="form-check form-switch">
                  <input class="form-check-input" name="status" type="checkbox" id="flexSwitchCheckChecked" 
                  
                  @if($setting->online_status == true)
                    checked
                  @endif
                  
                  >
                  <label class="form-check-label" for="flexSwitchCheckChecked">Change Website Status</label>
                </div>


              </div>

   
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Update</button>
          </div>

        </form>
        </div>
      </div>
    </div>

  </main>



@endsection




@section('script')

  <script>
     $(document).ready(function(){
     
        $('.deleteButton').on('click', function(){
              if (confirm("Are You Sure!")) {
                    const selectedId = $(this).attr('data-id');
                    console.log(selectedId);
                    elementFinder('form_user_id').value = selectedId;
                    elementFinder('user_delete_hdiden_form').submit();

              } else {
                $(this).preventDefault();
              }

        });


        function elementFinder(id){
            return document.getElementById(id);
        }
     });
  </script>
@endsection